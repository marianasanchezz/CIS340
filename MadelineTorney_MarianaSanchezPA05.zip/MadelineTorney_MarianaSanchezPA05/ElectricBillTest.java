package MadelineTorney_MarianaSanchezPA05;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;


public class ElectricBillTest {
	
	private static Customer[] customers;
	private String fileName;

public static void main(String[] args) {
	
	int custID, kwh, status, month;
	String fName, lName;
	
   //read the number of customer

	   // initializing array to fit number of customers
	  customers = new Customer[DataEntries.intInput("How many customers?")];
	  
		
		for (int i = 0; i< customers.length; i++) { //// start looping to read customer information and compute water bills 		
		//input customer rate - Use the Validation Methods in class DataEntries
		status = DataEntries.intInputChoice(0, 1, "Input Customer Type:" +
						  "\n0 - Residential Bill" + "\n1 - Commercial Bill");
				
		// Input Customer Number - Use the Validation Methods in class DataEntries
		custID = DataEntries.intInputSize(6, "Input Customer Number");
						
		// Enter customer name - Use the Validation Methods in class DataEntries
		fName = DataEntries.strInput("Input Customer First Name");
						    
		lName = DataEntries.strInput("Input Customer Last Name");
		
		// Enter number of gallons - Use the Validation Methods in class DataEntries
		kwh = DataEntries.intInput("Input Number of KWH");
		
		month = DataEntries.intInputRange(1,12,"Input month");
		
	// create a bill object based on the customer status: residential or commercial
     addCustomer(custID,fName, lName,status,kwh, month);
		}// end for
		
		display();
		sortArray();
		display();
		writeToFile();



} // end main

public static double getSum(){
	// finds the sum of the customers bills
	double sum =0;
	for (int i = 0; i< customers.length; i++) {
		sum+=customers[i].getBill().getBillAmount();
	}
	
	return sum;
}


public static double getAVG(){
	// finds the average of the customers bills
	double sum =0;
	for (int i = 0; i< customers.length; i++) {
		sum+=customers[i].getBill().getBillAmount();
	}
	
	return (sum/customers.length);
}


public static void addCustomer(int custID, String fName, String lName, int status, int kwh, int month){
	// add a new customer object to the customers array
	if (customers[Customer.getNoOfCustomers()] == null) {// you must double check the array size before adding a new customer to the array
		if (status == 0) { // residential
			customers [Customer.getNoOfCustomers()] = new Customer(custID, fName, lName, status, new Residential(kwh,month));
		}
		else { //commercial status = 1
			customers [Customer.getNoOfCustomers()] = new Customer(custID, fName, lName, status, new Commercial(kwh,month));
		}
	} else {
		JOptionPane.showMessageDialog(null, "Completed entering customers.");
	}
}



public static void sortArray(){
	// use the selection sort to sort the arrays based on bill amount
	
	for (int i = 0; i < customers.length - 1; i++) {
		
	      // Find the minimum in the list[i..list.length-1]
	      Customer currentMin = customers[i];
	      int currentMinIndex = i;

	      for (int j = i + 1; j < customers.length; j++) {
	    	  
	      // Update the if-statement to use the compareTo() method in the Customer class
	      if (currentMin.compareTo(customers[j]) > 0) {
	    	  currentMin = customers[j];
	          currentMinIndex = j;
	        }
	      }// end for j

	      		      
	      // Swap list[i] with list[currentMinIndex] if necessary;
	      if (currentMinIndex != i) {
	    	  customers[currentMinIndex] = customers[i];
	    	  customers[i] = currentMin;
	      }
	    }// end for i

	  JOptionPane.showMessageDialog(null, "Done Sorting Customer Data By Bill Values");
}// end sortBill

public static void writeToFile(){
	// write bill objects to file
	// File
			File file = new File("customers.txt");
		    
				    // Create a file
		    PrintWriter write = null;
			try {
				write = new PrintWriter(file);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			String out = "Electric Bill\n" + "CustomerID\t" + "First Name\t" + "Last Name\t" + "Customer Status\t" +
	                "No. of KWH\t" + "Month\t" + "Bill Amount";
	       for (int i =0; i < customers.length; i++)
		           out+= "\n" + customers[i].toString();
			
		    // Write formatted output to the file
		    write.print(out);
		   

		    // Close the file
		    write.close();
		    
		    JOptionPane.showMessageDialog(null, "Done Storing Customer Data into a File");
}

public static void display(){
	// display bill objects
	String out = "Electric Bill\n" + "CustomerID\t" + "First Name\t" + "Last Name\t" + "Status\t" +
            "No. of KWH\t" + "Month\t" + "Bill Amount";
for (int i =0; i < customers.length; i++)
 out+= "\n" + customers[i].toString();

out+= "\n\nSum of Bill Amount: $" + String.format("%.2f",getSum());

out+= "\nAverage Bill Amount: $" + String.format("%.2f", getAVG());

JOptionPane.showMessageDialog(null, new JTextArea(out));
}


} // end class

