package MadelineTorney_MarianaSanchezPA05;

import javax.swing.JOptionPane;

//add class template

public class Residential extends ElectricBill{


	// complete the constructor	
	Residential(int kwh, int month) { 
		super(kwh,month);
		computeBill();
	}

	@Override
	public void computeBill() {
		// compute the bill amount for a residential customer
		if (billMonth >= 6 && billMonth < 10) {  // SUMMER
			if (noOfKWH <= 500) { // First 500 KWH
				billAmount = BASE_RESIDENTIAL_CUST + (.04604 * noOfKWH);
			}else { // Residential & above 500 KWH
				billAmount = BASE_RESIDENTIAL_CUST + (.04604 * 500) + (.09 * (noOfKWH - 500));
			} // end inner

		}else if (billMonth>= 10 || billMonth< 6) { // WINTER
			billAmount  = BASE_RESIDENTIAL_CUST + (.04604 * noOfKWH);
		}else {
			JOptionPane.showMessageDialog(null, "ERROR");
		}// end outer if-else statement
	}






}


