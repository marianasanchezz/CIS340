package MadelineTorney_MarianaSanchezPA05;

//add class template

public abstract class ElectricBill implements BaseCharge{

	
	protected int noOfKWH;
	protected int billMonth;
	protected double billAmount;

	
// constructor
	ElectricBill(int noOfKWH,int billMonth) {
		this.noOfKWH = noOfKWH;
		this.billMonth=billMonth;
	}
	ElectricBill() {
		this.noOfKWH = 0;
		this.billMonth=0;
		this.billAmount=0;
	}


	// add the toString method
	@Override
	public String toString() {
		return noOfKWH + "\t" + billMonth + "\t$" + String.format("%.2f", billAmount);
	}
	
	public double getBillAmount() {
		return billAmount;
	}
	
	public void computeBill() {
		
	}

		 
}
