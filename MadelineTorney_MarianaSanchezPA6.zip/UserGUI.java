
package PA06;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Scanner;
import javax.swing.*;

import ICE6.BaseCharge;

public class UserGUI extends JFrame implements ActionListener {
	
	private String fileName;
	private static Customer[] customers;
	
	
	// declare all GUI components below
	// labels
	private JLabel lblFirstName;
	  private JLabel lblLastName;
	  private JLabel lblID;
	  private JLabel lblEnergy;
	  
	  // text fields
	  private JTextField txtFirstName;
	  private JTextField txtLastName;
	  private JTextField txtID;
	  private JTextField txtEnergy;
	  
	  // buttons
	  private JButton btnSubmit;
	  private JButton btnClose;
	  
	  // combo boxes
	  private JComboBox boxStatus;
	  private JComboBox boxMonth;
	  
	  // text area and scroll pane
	  private JTextArea textArea;
	  private JScrollPane jp;
	
	// constructor
	UserGUI(String fileName, int numCustomers) throws FileNotFoundException{
		
		this.fileName = fileName;
		
		// array of customers
		int fileSize = getFileLength(this.fileName);
		customers = new Customer[numCustomers+fileSize];
		
		// layout
		initComponent();
		doTheLayout();
		
		// buttons and action listeners
		this.btnClose.addActionListener(this);
		this.btnSubmit.addActionListener(this);
	
		// read data from file
		readFromFile(this.fileName);
		
	}

	private void initComponent(){
		
		// intialize the GUI components
		// labels
		this.lblFirstName = new JLabel("First Name");
		this.lblLastName = new JLabel("Last Name");
		this.lblID = new JLabel("Customer ID");
		this.lblEnergy = new JLabel("Energy (kWh)");
		
		// text
		this.txtFirstName = new JTextField(15);
		this.txtLastName = new JTextField(15);
		this.txtID = new JTextField(10);
		this.txtEnergy = new JTextField(10);
		this.txtFirstName.setToolTipText("You must provide a first name");
		this.txtLastName.setToolTipText("You must provide a last name");
		
		// combo boxes
		String[] statusOptions = {
		         "Residential",
		         "Commercial"
		};
		String[] monthOptions = {
		         "1 - Jan",
		         "2 - Feb",
		         "3 - Mar",
		         "4 - Apr",
		         "5 - May",
		         "6 - Jun",
		         "7 - Jul",
		         "8 - Aug",
		         "9 - Sep",
		         "10 - Oct",
		         "11 - Nov",
		         "12 - Dec"
		};
		this.boxStatus = new JComboBox(statusOptions);
		this.boxMonth = new JComboBox(monthOptions);
		
		// buttons
		this.btnSubmit = new JButton("Submit");
		this.btnClose = new JButton("Close");
		
		// text area
		this.textArea = new JTextArea("Program Display", 15, 60);
		this.jp = new JScrollPane(textArea);
		this.textArea.setEditable(false);
		
		  
	} // end initComponent

   private void doTheLayout(){
	   
		// Organize the components into GUI window
	   JPanel top = new JPanel();
	   JPanel center = new JPanel();
	   JPanel centerTop = new JPanel();
	   JPanel centerBottom = new JPanel();
	   JPanel bottom = new JPanel();
	   
	   // top
	   top.add(lblFirstName);
	   top.add(txtFirstName);
	   top.add(lblLastName);
	   top.add(txtLastName);
	   
	   // center border
	   center.setLayout(new BorderLayout());
	   center.add(centerTop,BorderLayout.CENTER);
	   center.add(centerBottom,BorderLayout.SOUTH);
	   
	   
	   // center top
	   centerTop.add(lblID);
	   centerTop.add(txtID);
	   centerTop.add(boxStatus);
	   centerTop.add(lblEnergy);
	   centerTop.add(txtEnergy);
	   centerTop.add(boxMonth);
	   
	   // center bottom
	   centerBottom.add(btnSubmit);
	   centerBottom.add(btnClose);
	   
	   // jb scroll pane
	   bottom.add(jp);
	   
	   // add all to JFrame
	   this.add(top, "North");
	   this.add(center, "Center");
	   this.add(bottom, "South");
	   
	} // end doLayout

	@Override
	public void actionPerformed(ActionEvent event) {
		//call appropriate methods as required based on user actions
		if (event.getSource() == this.btnClose) {
			this.closeButtonClicked();
		} else if (event.getSource() == this.btnSubmit){
			this.submitButtonClicked();
		} 
	} // end actionPerformed

	private void submitButtonClicked(){
		// code to be executed once the submit button is clicked
		//add customer object to the customers[] array
		//display the customerc objects followed by sum and average
		String fName = "", lName="", month = "", status = "";
		int custID = 0, kwh = 0;
		
		
		// read and validate FIRST Name
		if (this.txtFirstName.getText().trim().isEmpty()) {
			JOptionPane.showMessageDialog(this.txtFirstName, "Invalid Customer First Name");
			return;
		} else {
		  fName = this.txtFirstName.getText().trim();
		}
		// read and validate LAST Name
		if (this.txtLastName.getText().trim().isEmpty()) {
			JOptionPane.showMessageDialog(this.txtLastName, "Invalid Customer Last Name");
			return;
		} else {
		  lName = this.txtLastName.getText().trim();
		}
		
	// read and validate input custID, use try catch for input validations
		try { 
		   custID = Integer.parseInt(this.txtID.getText().trim());
			if (this.txtID.getText().trim().length() != 8) {
				throw new Exception();
			}
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(this.txtID, "Invalid customer ID");
			this.txtID.setText("");
			return;
		}
		 // validate kwh
		try {
		   kwh = Integer.parseInt(this.txtEnergy.getText().trim());
			if (this.txtEnergy.getText().isEmpty()) {
				throw new Exception();
			}
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(this.txtEnergy, "Invalid Energy KWH");
			this.txtEnergy.setText("");
			return;
		}

    // validate status here
		 /// hold up dont know how this works w month drop down option SAME W STATUS drop down
	  if (this.boxStatus.getSelectedItem() == null) { // may be best for isEmpty
	  	JOptionPane.showMessageDialog(this.boxStatus,"Invalid Customer Status");
	  return;
	}
	  else {
	  	status = (String) this.boxStatus.getSelectedItem(); // idk if this is good
	  }
	  // validate month
	  if (this.boxMonth.getSelectedItem() == null) { // may be best for isEmpty
	  	JOptionPane.showMessageDialog(this.boxMonth,"Invalid Month");
	  return;
	}
	  else {
	  	month = (String) this.boxMonth.getSelectedItem(); // idk if this is good
	  }
	
	 addCustomer(custID, fName, lName, status, kwh, month);
		
		// clear text fields from data
		
		this.txtFirstName.setText("");
		this.txtLastName.setText("");
		this.txtID.setText("");
		this.txtEnergy.setText("");
		this.boxStatus.setSelectedItem(null);
		this.boxMonth.setSelectedItem(null);
		
		
		
		
	}

	private void closeButtonClicked(){
		
		// sort to file
		for (int i = 0; i < Customer.getNoOfCustomers() -1; i++) {
		      // Find the minimum in the customers[i..customers.length-1]
		      Customer currentMin = customers[i];
		      int currentMinIndex = i;

		      for (int j = i + 1; j < Customer.getNoOfCustomers(); j++) {
		        if (currentMin.compareTo(customers[j]) > 0) {
		          currentMin = customers[j];
		          currentMinIndex = j;
		        }
		      }

		      // Swap customers[i] with customers[currentMinIndex] if necessary;
		      if (currentMinIndex != i) {
		        customers[currentMinIndex] = customers[i];
		        customers[i] = currentMin;
		      }
		    }
		
		File file = new File("outputElectricBill.txt");

	    // Create a file
		PrintWriter output = null;
		try {
			output = new PrintWriter(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		for (int i =0; i < Customer.getNoOfCustomers(); i++)
			output.println(customers[i].toString());

	    // Close the file
	    output.close();
	    
	    JOptionPane.showMessageDialog(null, "Done Writing Array to file outputElectricBill.txt");
	    
	    
	    // code to be executed once the close button is clicked
	    // It must show a goodbye message and terminate the program
	 	JOptionPane.showMessageDialog(null, "Program Exit");
		System.exit(0);

	} // end closeButtonClicked

	
public int getFileLength(String fileName) throws FileNotFoundException {
		
	    //To Complete in class
	    // read data from customers.txt
		// Create a File instance
	    File file = new File(fileName);
	
	    // Create a Scanner for the file
	    Scanner sc = new Scanner(file);

	    // Read data from a file, the data fields are separated by ',' 
	    // Change the Scanner default delimiter to ','
	   // Start reading data from file using while loop
	 
	    int i = 0;
	    while (sc.hasNext()) {
		  sc.nextLine();
		  i++;
	   }// end while
		
		
		// Close the file
	    sc.close();
	    
	    
	    
	     // display message the program done reading data
	     JOptionPane.showMessageDialog(null, "Start Reading Data From File \"inputWaterBill.txt\" For " + i + " Customers ");
	     
	     return i;
	     
	  } //end getfilelength

private void readFromFile(String filename) throws FileNotFoundException {
	
	// Create a File instance
    java.io.File file = new java.io.File(fileName);

    // Create a Scanner for the file
    Scanner input = new Scanner(file);

 
    // Read data from a file
    while (input.hasNext()) {
      String line = input.nextLine();
      String[] customer = line.split(",");
      
      addCustomer(Integer.parseInt(customer[0].trim()),  // custID
      		customer[1].trim(), //First Name
      		customer[2].trim(), //Last Name
      		customer[3].trim(),//status
      		Integer.parseInt(customer[4].trim()), //KWH
      		customer[5].trim());	 //month 
    }// end-while

    // Close the file
    input.close();
    JOptionPane.showMessageDialog(null, "Done Reading Customers Data From File " + fileName + " and Creating "
    		+ this.getFileLength(filename) + " Customer Objects"  );
    
    // display the data read from file
    display();
    
  } //end readfromfile

public void addCustomer(int custID, String fName, String lName, String status, int kwh, String month){
	
	// add Customer object to the customers array
	// This method must check whether the array is full 
	if (Customer.getNoOfCustomers() < customers.length) {
	    if (status.equals("Residential"))  {// this may not work right
		        customers[Customer.getNoOfCustomers()] =
				new Customer(custID, fName, lName, status, new Residential(kwh, month));
	    }	else if (status.equals("Commercial")) {
			    customers[Customer.getNoOfCustomers()] =
			    new Customer(custID, fName, lName, status, new Commercial(kwh, month));
	    } else {
	    	JOptionPane.showMessageDialog(null, "Reading file error");
	    }
	} else {
		JOptionPane.showMessageDialog(btnSubmit, "The customers array is full.");
	}
	    
	    
	    this.display();
					
}// end addCustomer

private void display(){
	
	// prepare the output
	String message = "Electric Bill: \n" + "First Name\t" + "Last Name\t" + "ID\t" + "Status\t" + "Bill\t";
	for (int i = 0; i < Customer.getNoOfCustomers(); i++)
	   message+="\n" + customers[i].toString();
	
	// call the method average
	message+= "\nAverage Bill Values: " + String.format("%.2f", avg()) + "\nSum Bill Values: " + String.format("%.2f", sum());
	
	// display message to the text area, use setText() method
	// To Complete
	this.textArea.setText(message);
	
	
}// end display

private double avg(){
	double sum =0;
	for (int i = 0; i < Customer.getNoOfCustomers(); i++)
		sum+=customers[i].getBill().getBillAmount();
	
	return sum/Customer.getNoOfCustomers() ;
}//end avg

public static double sum(){
	double sum =0;
	for (int i = 0; i < Customer.getNoOfCustomers(); i++)
		sum+=customers[i].getBill().getBillAmount();
	
	return sum;
}


	public static void main(String[] args) throws FileNotFoundException {
		int numCustomers = 0;
		numCustomers = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter number of customers to read from the user."));
		
		UserGUI frame = new UserGUI("customers.txt", numCustomers);
		frame.setTitle("User Electric Bill");
	    frame.pack();
	    frame.setLocationRelativeTo(null); // Center the frame
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    frame.setVisible(true);

	}

}

