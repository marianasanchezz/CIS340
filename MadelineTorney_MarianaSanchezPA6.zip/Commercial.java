package PA06;

import javax.swing.JOptionPane;

//add class template

public class Commercial extends ElectricBill{


	// complete the constructor	
	public Commercial(int kwh, String month) { 
		super(kwh, month);
		computeBill();
	}

	@Override
	public void computeBill() {
		// compute the bill amount for a commercial customer
		
		
		if (this.billMonth.charAt(0) >= 6 && billMonth.charAt(0) < 10) {  // SUMMER
			billAmount = BASE_COMMERCIAL_CUST + (0.06450 * noOfKWH);
		} else if (billMonth.charAt(0) >= 10 || billMonth.charAt(0)< 6) { // WINTER
			billAmount = BASE_COMMERCIAL_CUST + (.03920 * noOfKWH);
		} else {
			JOptionPane.showMessageDialog(null, "ERROR");
		}
	}
	
}