package PA06;

// add class template
public class Customer implements Comparable<Customer>{

	private int customerID;
	private String fName;
	private String lName;
	private String status;
	private ElectricBill bill;
	private static int numberOfCustomers = 0;
	
	// add the class overloaded constructor
	public Customer(int custID, String fName, String lName, String status, ElectricBill bill) {
		this.customerID = custID;
		this.fName = fName;
		this.lName = lName;
		this.status = status;
		this.bill = bill;
		numberOfCustomers++;
	}
	
	public Customer() {
		this(0, "", "", "", null);
	}


	// add setter and getter methods
	
	public String getfName() {
		return fName;
	}
	
	public String getlName() {
		return lName;
	}
	
	public int getID() {
		return customerID;
	}
	
	public void setID(int custID) {
		this.customerID = custID;
	}
	
	public ElectricBill getBill() {
		return bill;
	}

	
	public static int getNoOfCustomers() {
		return numberOfCustomers;
		
	}
	
	public int compareTo(Customer cust) {
		if (this.fName.compareTo(cust.fName) > 0)
			return 1;
		else if (this.fName.compareTo(cust.fName) < 0 ) // sorting by name
			return -1;
		else
		   return 0;
	}

	

	// override the toString() method
	@Override
	public String toString() {
		return fName + "\t" + lName + "\t" + customerID + "\t" + status + "\t" + bill.toString();

	}


}
