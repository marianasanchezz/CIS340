package PA05;

import javax.swing.JOptionPane;


public class ElectricBillTest {
	
	private static Customer[] customers;
	private String fileName;

public static void main(String[] args) {
	
	int custID, kwh, status, month;
	String fName, lName;
	
   //read the number of customer

	   // initializing array to fit number of customers
	  customers = new Customer [DataEntries.intInput("How many customers?")];
	  
		
		for (int i = 0; i< customers.length; i++) { //// start looping to read customer information and compute water bills 		
		//input customer rate - Use the Validation Methods in class DataEntries
		status = DataEntries.intInputChoice(0, 1, "Input Customer Type:" +
						  "\n0 - Residential Bill" + "\n1 - Commercial Bill");
				
		// Input Customer Number - Use the Validation Methods in class DataEntries
		custID = DataEntries.intInputSize(6, "Input Customer Number");
						
		// Enter customer name - Use the Validation Methods in class DataEntries
		fName = DataEntries.strInput("Input Customer First Name");
						    
		lName = DataEntries.strInput("Input Customer Last Name");
		
		// Enter number of gallons - Use the Validation Methods in class DataEntries
		kwh = DataEntries.intInput("Input Number of KWH");
		
		month = DataEntries.intInputRange(1,12,"Input month");
		
	// create a bill object based on the customer status: residential or commercial
     addCustomer(custID,fName, lName,status,kwh, month);
		}// end for



} // end main

public static double getSum(){
	// finds the sum of the customers bills
	return 0;
}


public static double getAVG(){
	// finds the average of the customers bills
	return 0;
}


public static void addCustomer(int custID, String fName, String lName, int status, int kwh, int month){
	// add a new customer object to the customers array
	if (customers[Customer.getNoOfCustomers()] == null) {// you must double check the array size before adding a new customer to the array
		if (status == 0) { // residential
			customers [Customer.getNoOfCustomers()] = new Customer (custID, fName, lName, status, new Residential (kwh,month));
		}
		else { //commercial status = 1
			customers [Customer.getNoOfCustomers()] = new Customer(custID, fName, lName, status, new Commercial(kwh,month));
		}
	} else {
		JOptionPane.showMessageDialog(null, "Completed entering customers.");
	}
}



public static void sortArray(){
	// use the selection sort to sort the arrays based on bill amount

}

public static void writeToFile(){
	// write bill objects to file
}

public static void display(){
	// display bill objects
}


} // end class

