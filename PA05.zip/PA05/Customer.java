package PA05;


// add class template
public class Customer {

	private int customerID;
	private String fName;
	private String lName;
	private int status; // 0 (res) or 1 (com)
	private ElectricBill bill;
	private static int numberOfCustomers = 0;
	
	Customer(int customerID, String fName, String lName, int status, ElectricBill bill) {
		this.customerID = customerID;
		this.fName = fName;
		this.lName = lName;
		this.status = status;
		this.bill = bill;
		numberOfCustomers++;
	}


	// add the class overloaded constructor WHAT?

	// add setter and getter methods
	public String getFName() {
		return fName;
	}
	public String getLName() {
		return lName;
	}

	public void setFName(String fName) {
		this.fName = fName;
	}
	public void setLName(String lName) {
		this.lName = lName;
	}

	public int getCustID() {
		return customerID;
	}
	public void setNumber(int custID) {
		this.customerID = custID;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	
//  need edits here below 
	public ElectricBill getBill() {
		return bill;
	}

	public static int getNoOfCustomers() {
		return numberOfCustomers;
	}

	@Override
	public String toString() {
		return customerID + "\t" + fName +" " + lName + "\t" + status + "\t" + bill.toString();
	}
	// override the toString() method


}
