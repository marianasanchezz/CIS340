package PA05;

import javax.swing.JOptionPane;

//add class template

public class Commercial extends ElectricBill{


	// complete the constructor	
	public Commercial(int kwh, int month) { 
		super(kwh, month);
		computeBill();
	}
	@Override
	public void computeBill() {
		// compute the bill amount for a commercial customer
		if (billMonth >= 6 && billMonth < 10) {  // SUMMER
			billAmount = BASE_COMMERCIAL_CUST + (0.06450 * noOfKWH); // idk if these reference correctly
		} else if (billMonth >= 10 || billMonth < 6) { // WINTER
			billAmount = BASE_COMMERCIAL_CUST + (.03920 * noOfKWH);
		} else {
			JOptionPane.showMessageDialog(null, "ERROR");
		}
	}
	
}