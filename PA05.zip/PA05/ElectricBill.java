package PA05;

//add class template

public abstract class ElectricBill implements BaseCharge{

	
	protected int noOfKWH;
	protected int billMonth;
	protected double billAmount;

	
// constructor
	public ElectricBill(int noOfKWH,int billMonth) {
		this.noOfKWH = noOfKWH;
		this.billMonth=billMonth;
	}
	public ElectricBill() {
		this.noOfKWH = 0;
		this.billMonth=0;
	}


	// add the toString method
	@Override
	public String toString() {
		return "\nKWH:" + noOfKWH + "\tMonth" + billMonth + "\tBill Amount:" + billAmount;
	}
	

		 
}
