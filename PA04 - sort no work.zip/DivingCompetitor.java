package PA04;

public class DivingCompetitor {
	String firstName = "";
	String lastName = "";
	int[] points = new int[7];
	static int difficultyLevel = 0;
	double avgPoints = 0;
	double finalScore = 0;  

	DivingCompetitor() { // default constructor
		this("","");
	}
	
	DivingCompetitor(String firstName, String lastName) { // parameter constructor
    this.firstName = firstName;
    this.lastName = lastName;
    this.generatePoints();
    this.getAvg(this.points);
    this.calcFinalScore();
}
	
	public void generatePoints() {
		int[] points = new int[7];
		
		for (int i = 0; i < points.length; i++) {
			points[i] = (int)(Math.random() * 10) + 1;
			//System.out.print(points[i] + " ");
		}
		this.points = points; // i think this works right?
	} // end generatePoints
	
	public void getAvg(int[] points) {
		int sum = 0;
		double average = 0;
		
		int min = points[0]; // find minimum of points array
			for (int i = 0; i < points.length; i++) {
				if (points[i] < min) {
					min = points[i];
				} else {
					continue;
				}
			} // end for loop
		int max = points[0]; // find maximum of points array
			for (int i= 0; i < points.length; i++) {
				if (points[i] > max) {
					max = points[i];
				} else {
					continue;
				}
			} // end for loop
		for (int i = 0; i < points.length; i++) {
			sum += points[i]; // gather sum of all points array
		}
		average = (sum - (min + max)) / 5;
		this.avgPoints = average;
	}
	
	public void calcFinalScore() {
		double finalScore = (double) (this.avgPoints * difficultyLevel);
		this.finalScore = finalScore;
	}
	public double getFinalScore() {
		return finalScore;
	}
	
	
	} // end class


