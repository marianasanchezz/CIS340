//*************************************************************************** 
//*  
//* CIS 340                   SP 2023                 Madeline Torney / Mariana Sanchez
//*  
//*                            PA0401
//*           			Diving competition 
//*  
//*
//*                  Date Created  2.22.23
//*  
//*              File Name:  MadelineTorney_MarianaSanchezPAO401
//*  
//*************************************************************************

package PA04;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import javax.swing.JOptionPane;

public class MadelineTorney_MarianaSanchezPA04 {
	
	static String displayOutput = "";
	
	public static void sortCompArr(DivingCompetitor [] custArray) {
		
		int i,j;
		
		for (i = 0; i < custArray.length; i++) { // starting with position 0
			int currentMaxIndex = i;
			double currentMax = custArray[i].finalScore;
			String currentMaxInfoFN=custArray[i].firstName;
			String currentMaxInfoLN=custArray[i].lastName;
			
			
			for(j=i+1;j<custArray.length;j++) {
				if(custArray[j].finalScore > currentMax) { // so if the right final score is greater than left
					currentMax=custArray[j].finalScore; // it will become current max TEMP placeholder
					currentMaxInfoFN =custArray[j].firstName; // first name too
					currentMaxInfoLN	= custArray[j].lastName; // last name too 
					currentMaxIndex=j;
					
				}//end if
			}//end inner for
			
			if(currentMaxIndex!=i) { // we only enter if order is changing
				custArray[currentMaxIndex].finalScore = custArray[i].finalScore; // so where we found the new max
				custArray[i].finalScore=currentMax;
			
				custArray[currentMaxIndex].firstName=custArray[i].firstName;
				custArray[currentMaxIndex].lastName=custArray[i].lastName;
				
				custArray[i].firstName=currentMaxInfoFN;
				custArray[i].lastName=currentMaxInfoLN;
			}
		}//end outer for
		
		//Update the output variable after Sorting
		for(i=0;i<custArray.length;i++)	
			displayOutput += "\n" + custArray[i].firstName + " " + custArray[i].lastName +"\t\t\t" + custArray[i].finalScore;
	}
	
	
	public static void writeToFile() throws FileNotFoundException{
	String fileName = "Scores.txt";
	
	File file = new File(fileName);

    // Create a file
    PrintWriter output = new PrintWriter(file);

    // Write formatted output to the file
    output.print(displayOutput);

    // Close the file
    output.close();
	}
	
	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		int numDivers = 0;
		boolean loop = false;
		int difficultyLevel = 0;
		displayOutput+="Drivers Name: \t\tFinal Score:";
		
		// prompt user to enter number of divers
		while (loop == false) {
			try {
				numDivers = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter number of divers:"));
				if (numDivers <= 0) {
					throw new Exception();
				} else {
					loop = true;
				} // end else
			} catch (Exception ex) {
				JOptionPane.showMessageDialog(null, "Invalid input. Enter a number between greater than 0.");
				loop = false;
			} // end try catch
		} // end while
		
		loop = false;
		DivingCompetitor[] competitorsArr = new DivingCompetitor[numDivers];
		
		// prompt user to enter difficulty level
		while (loop == false) {
			try {
				difficultyLevel = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter difficulty level:"));
				if (difficultyLevel <= 0 || difficultyLevel >= 6) {
					throw new Exception();
				} else {
					loop = true;
				} // end else
			} catch (Exception ex) {
						JOptionPane.showMessageDialog(null, "Invalid input. Enter a number between 1 and 5.");
						loop = false;
					} // end try catch
				} // end while
				
		loop = false;
		
		// read first name for divers & put in object array
		for (int i = 0; i < numDivers; i++) {
			DivingCompetitor.difficultyLevel = difficultyLevel; //?? auto change here for static ref
			
			String fName = "", lName = "";
			while (loop == false) {
				try {
					fName = JOptionPane.showInputDialog(null, "Enter a diver's first name (" + (i+1) + "):");
					if (fName.isEmpty()) {
						throw new Exception();
					} else {
						loop = true;
	
					} // end else
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "Invalid input.");
					loop = false;
				} // end try catch
			} // end first name while
	
			loop = false;

			// read last name for divers
			while (loop == false) {
				try {
			   	lName = JOptionPane.showInputDialog(null, "Enter a diver's last name (" + (i+1) + "):");
					if (lName.isEmpty()) {
						throw new Exception();
					} else {
						loop = true;
						
					} // end else
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "Invalid input.");
					loop = false;
				} // end try catch
			} // end while

			loop = false;
			competitorsArr[i] = new DivingCompetitor(fName, lName);
	
			
		} // end for loop
		sortCompArr(competitorsArr);
		writeToFile();

		
		loop = false;
		
		
		
		
		
	} // end

}// end